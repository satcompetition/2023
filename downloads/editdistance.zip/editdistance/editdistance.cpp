/**
 * editdistance.cpp
 * Purpose: Compute the Levenshtein (minimal number of edit operations) distance between two files
 * without taking any type of white spaces into consideration.
 * Input two files that are
 * @author Adrian Balint
 * @version sc13_0.1
 */
#include <string>
#include <fstream>
#include <streambuf>
#include <iostream>
#include <cctype>
#include <algorithm>
using namespace std;

/**
 * Compute Levenshtein Distance code by Martin Ettl, 2012-10-05
 * http://rosettacode.org/wiki/Levenshtein_distance#C.2B.2B
 * @param s1,s2 Two strings that are to be compared
 * @return the number of edit operations to transform s1 in s2
 */

size_t uiLevenshteinDistance(const std::string &s1, const std::string &s2) {
	const size_t m(s1.size());
	const size_t n(s2.size());

	if (m == 0)
		return n;
	if (n == 0)
		return m;

	size_t *costs = new size_t[n + 1];

	for(size_t k=0; k<=n; k++ ) costs[k] = k;

	size_t i = 0;
	for (std::string::const_iterator it1 = s1.begin(); it1 != s1.end(); ++it1, ++i) {
		costs[0] = i + 1;
		size_t corner = i;

		size_t j = 0;
		for (std::string::const_iterator it2 = s2.begin(); it2 != s2.end(); ++it2, ++j) {
			size_t upper = costs[j + 1];
			if (*it1 == *it2) {
				costs[j + 1] = corner;
			} else {
				size_t t(upper < corner ? upper : corner);
				costs[j + 1] = (costs[j] < t ? costs[j] : t) + 1;
			}

			corner = upper;
		}
	}

	size_t result = costs[n];
	delete[] costs;

	return result;
}
/**
 * Read the content of a file into a string.
 * @param file The file name.
 * @return string containing the content of the file
 */
std::string readFromFile(char* file) {
	std::ifstream filestr(file);
	std::string str;
	filestr.seekg(0, std::ios::end);
	str.reserve(filestr.tellg());
	filestr.seekg(0, std::ios::beg);
	str.assign((std::istreambuf_iterator<char>(filestr)),
	std::istreambuf_iterator<char>());
	return str;
}
/**
 * Check if a file exists by trying to open it.
 * @param file The file name.
 * @return 0 if file does not exist or can not be opened, 1 else
 */

bool fexists(const char *filename) {
	ifstream ifile(filename);
	return ifile;
}

int main(int argc, char **argv) {
	if (argc != 3) {
		cout << "Usage: ./editdist <file_1> <file_>" << endl;
		return -1;
	}

	if (!fexists(argv[1])) { //check if the first file exists
		cout << "can not open/find file: " << argv[1] << endl;
		return -1;
	}
	if (!fexists(argv[2])) { //check if the second file exists
		cout << "can not open/find file: " << argv[2] << endl;
		return -1;
	}

	string s1 = readFromFile(argv[1]);
	s1.erase(::remove_if(s1.begin(), s1.end(), ::isspace), s1.end()); //remove all empty spaces

	string s2 = readFromFile(argv[2]);
	s2.erase(::remove_if(s2.begin(), s2.end(), ::isspace), s2.end()); //remove all empty spaces

	cout << "Computing  edit (Levenshtein) distance between files: \n" << argv[1] << endl << argv[2] << endl;
	cout << "editdistance= " << uiLevenshteinDistance(s1, s2) << endl;
	return 0;
}
